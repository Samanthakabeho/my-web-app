//Storing the current temperature in celsius
let temperature =30;
if(temperature < 20){
    console.log("it's cold");
} else if(temperature >= 20 && temperature<=30) {
    console.log("it's moderate");
} else{
    console.log("it's too hot");
}



