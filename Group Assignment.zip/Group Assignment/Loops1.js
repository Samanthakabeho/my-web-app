//Printing numbers from 1 to 10
for(let x =1;x<=10;x++){
    console.log(x);
}