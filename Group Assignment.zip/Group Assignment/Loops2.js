// Printing multiplication table of 5
for(k=1;k<=10;k++){
    console.log(`5 * ${k} = $ {5 * k}`);
}