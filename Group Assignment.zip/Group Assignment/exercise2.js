//Checking if a person is eligible foe admission to school
let score =50;
if (score >= 70){
    console.log("Eligible for admission");
} else if(score >= 50 && score <= 69){
    console.log("Admission on probation");
} else{
    console.log("Not eligible for admission");
}