//Check if the village has enough water
let water = 200
if(water >= 500){
    console.log("Enough water");
} else if(water >=200 && water <=500){
    console.log("Water is limited");
} else{
    console.log("water shortage");
}