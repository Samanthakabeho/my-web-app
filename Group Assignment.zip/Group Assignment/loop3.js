//Finding the sum of numbers from 1 to 100
let sum = 0;
let M =1;

while(M<= 100){
    sum += M;
    M++;
}
console.log(`the sum of numbers from 1 to 100 is ${sum}`);
