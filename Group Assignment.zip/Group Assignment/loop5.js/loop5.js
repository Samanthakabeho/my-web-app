let i = 1;

while (i <= 10) {
    console.log(i);
if (i == 7) {
    break;

    }
    i ++;
}